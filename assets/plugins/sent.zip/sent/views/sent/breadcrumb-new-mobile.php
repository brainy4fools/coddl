<div class="text-center">
    <div class="col-xs-4"><a href="#" id="demo"><i class="fa fa-angle-left"></i> Back</a></div>
    <div class="col-xs-4"><strong>New sent</strong></div>
    <div class="col-xs-4"></div>
</div>